package com.morales.mx.zona_fit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZonaFitApplicationTests {

	@Test
	void contextLoads() {
	}

}
