package com.morales.rh;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RhApplicationTests {

	@Test
	void contextLoads() {
	}

}
